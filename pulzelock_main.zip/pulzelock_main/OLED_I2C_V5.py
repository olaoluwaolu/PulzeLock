import sys
sys.path.insert(0, '/home/art/testDir/lib')

import json
import time

import board
import digitalio
from PIL import Image, ImageDraw, ImageFont
import adafruit_ssd1306

# Reset Pin
oled_reset = digitalio.DigitalInOut(board.D4)

# parameters
wdth = 128
hght = 64
brdr = 5

# Use for I2C.
i2c = board.I2C()  # uses board.SCL and board.SDA
oled = adafruit_ssd1306.SSD1306_I2C(wdth, hght, i2c, addr=0x3D, reset=oled_reset)

# Clear display.
oled.fill(255)
oled.show()

# Create blank image for drawing.
# Make sure to create image with mode '1' for 1-bit color.
image = Image.new("1", (oled.width, oled.height))

# Get drawing object to draw on image.
draw = ImageDraw.Draw(image)

# Draw a white background
draw.rectangle((0, 0, oled.width-1, oled.height-1), outline=255, fill=255)
draw.rectangle((1, 1, oled.width-2, oled.height-2), outline=0, fill=255)

# Load default font.
font = ImageFont.load_default()

with open('output.txt', 'r') as file:
    content = file.read()

# if sys.argv[1] == "ID":
#    print(f"entered ID")
#    if sys.argv[2] == "yes":
text = str(content)
bbox = font.getbbox(text)
(font_width, font_height) = bbox[2] - bbox[0], bbox[3] - bbox[1]
draw.text((15, 12), text, font=font, fill=0,)
# elif sys.argv[1] == "VITAL":
#    print(f"entered VITAL")
#else:
#    print(f"no recognized arg passed")


# Draw Some Text
#text = "Hello everyone\nin Senior Lab!"
#bbox = font.getbbox(text)
#(font_width, font_height) = bbox[2] - bbox[0], bbox[3] - bbox[1]
#draw.text(
#    (15, 15),
#    text,
#    font=font,
#    fill=0,
#)

# Display image
oled.image(image)
oled.show()
