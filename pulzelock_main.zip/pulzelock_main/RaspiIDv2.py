import json

from keras.models import load_model
import numpy as np

#Loads the trained model and identifies a PPG based on the trained model

# Function to apply a moving average filter
def moving_average(data, window_size):
    return np.convolve(data, np.ones(window_size)/window_size, mode='valid')

# Load the saved model
loaded_model = load_model("ppg_model.h5")

# Prepare your new PPG signal for prediction (assuming it's already processed like in load_data)
ppgFilePath = r"USER.json"
# ppgFilePath = r'G:\My Drive\cupoLaptop\Research\Research\Pycharm\ppgResearch\RGB_SrLab_PPG\Logan_trial_10.json'
with open(ppgFilePath, "r") as f:
    ppg = json.load(f)

filteredPPG = moving_average(ppg,5)

new_ppg_signal = filteredPPG  # Replace with your actual PPG data
new_ppg_signal = np.expand_dims(new_ppg_signal, axis=0)  # Add batch dimension
new_ppg_signal = np.expand_dims(new_ppg_signal, axis=2)  # Add channel dimension if needed

# Make predictions
predictions = loaded_model.predict(new_ppg_signal)
predicted_class = np.argmax(predictions, axis=1)

# Output the identified user
user_mapping = {0: "Unauthorized", 1: "Jonas", 2: "Logan", 3: "Olaolu"}  # Update based on your actual mapping
identified_user = user_mapping[predicted_class[0]]
print(f"Identified User: {identified_user}")

output = open("output.txt", 'w')

if (identified_user == "Unauthorized"):
    output.write(f"\n Access Denied")
else:
    output.write(f"\n Weclome, {identified_user}")


