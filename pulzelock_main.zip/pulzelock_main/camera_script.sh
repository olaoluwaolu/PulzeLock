#!/bin/bash

lengthRecord=20000
VIDEO_DIR="./Videos"
FILEPATH="$VIDEO_DIR/USER_VID.mp4"

echo $$ > PID_camera_script.txt

if [ -z "$1" ]; then
echo "No argument passed"
echo "[Camera Module]: Camera control called without argument" >> Logs.txt
# code for no passed argument

elif [ "$1" = "init" ]; then
echo "[Camera Module]: Initializing Camera Module" >> Logs.txt
libcamera-vid -t 30000 -o "$FILEPATH"
echo "[Camera Module]: Camera initialization video saved at /MainPPGDir/Videos/init.mp4" >> Logs.txt

elif [ "$1" = "record" ]; then
    echo "[Camera Module]: Camera recording new video..." >> Logs.txt
    echo "Please place your finger over the camera..."
    echo -e "Please place\nyour finger\nover the camera" > output.txt
    python OLED_I2C_V5.py
    sleep 3
    echo "5"
    echo "5" > output.txt
    python OLED_I2C_V5.py
    sleep 1
    echo "4"
    echo "4" > output.txt
    python OLED_I2C_V5.py
    sleep 1
    echo "3"
    echo "3" > output.txt
    python OLED_I2C_V5.py
    sleep 1
    echo "2"
    echo "2" > output.txt
    python OLED_I2C_V5.py
    sleep 1
    echo "1"
    echo "1" > output.txt
    python OLED_I2C_V5.py
    sleep 1
    echo "Recording..." > output.txt
    python OLED_I2C_V5.py
    libcamera-vid -t "$lengthRecord" -o "$FILEPATH"
    echo "Recording saved as $FILEPATH"
    echo "[Camera Module]: New video saved as $FILEPATH" >> Logs.txt
	# potentially need a delay command here for waiting until the vid finished recording: sleep "$2"+1
fi

export FILEPATH
