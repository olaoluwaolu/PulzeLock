#!/bin/bash

echo $$ > PID_system_control.txt
echo "[System Control] Running Camer Script in $SYS_MODE"
source ./camera_script.sh record > /dev/null 2>&1
sleep 1
echo "[System Control] Running Python Scripts in $SYS_MODE"
python python_ppg.py $FILEPATH $SYS_MODE

echo "[System Control] PPG is processed"

if [ "$SYS_MODE" = "ID" ]; then
    python RaspiIDv2.py
    echo "[System Control] I2C script ouputs authentication results"
    python3 OLED_I2C_V5.py $SYS_MODE
elif [ "$SYS_MODE" = "VITAL" ]; then
    python3 OLED_I2C_V5.py $SYS_MODE
fi


sleep 5

#clean video and json
rm -f "$FILEPATH" USER.json output_ppg.txt output.txt
