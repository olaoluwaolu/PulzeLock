#!/bin/bash

#to be used to record videos for training algorithm
#enter the name of the person recording as an argumen
#usage: ./system_control_trials.sh <user's name>

trials=8
#mkdir $1
for i in $( eval echo {1..$trials} )
do
    echo "Starting the recording in 5 seconds..."
    source ./camera_script_trials.sh record > /dev/null
    sleep 1
    python python_ppg.py $FILEPATH TRIAL "$1 Trial $i" > /dev/null
    echo "PPG is processed"
    echo "Please type pulse oximeter readings separated by commas: "
    read baseline
    echo -e "$1 Trial $i pulseOx,$baseline" >> vitals_trials.csv
    if [ "$i" -eq "$trials" ]; then
	echo "All $trials trials complete!"
	exit
    fi
    echo "Next trial? (yes/no)"
    read yes_no
    if [ "$yes_no" = "no" ]; then
	exit
    fi
    sleep 1
done

rm -f "$FILEPATH"
