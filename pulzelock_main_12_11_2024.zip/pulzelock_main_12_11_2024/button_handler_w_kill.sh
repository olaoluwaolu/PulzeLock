#!/bin/bash
SYS_MODE="INIT"
GPIOListen=true
RightBtnGPIO=595
LeftBtnGPIO=596
buttonPressedValue=1
RightBtnSet=false
LeftBtnSet=false
longPressDuration=5  # Duration in seconds to detect a long press

echo "[Button Handler] Giving time for system to boot properly...Sleeping 15"
sleep 15

which python > env_yes_no
#make it check if Pulzelock is activated if not to activate it

# Initialize GPIO
if [ ! -d /sys/class/gpio/gpio"$RightBtnGPIO" ]; then
    echo "$RightBtnGPIO" > /sys/class/gpio/export
    sleep 0.1
    echo "in" > /sys/class/gpio/gpio"$RightBtnGPIO"/direction
    echo "[Button Handler] Right button has been initialized"
fi

if [ ! -d /sys/class/gpio/gpio"$LeftBtnGPIO" ]; then
    echo "$LeftBtnGPIO" > /sys/class/gpio/export
    sleep 0.1
    echo "in" > /sys/class/gpio/gpio"$LeftBtnGPIO"/direction
    echo "[Button Handler] Left button has been initialized"
fi

#GPIOListen=false
#echo -e "\n        Access Denied!" > output.txt
#python3 OLED_I2C_V5.py
# Main loop
while [ "$GPIOListen" = true ]; do
    echo -e "Welcome to \nPulzeLock!" > output.txt
    echo "<= Vitals     ID Mode =>" >> output.txt
    python3 OLED_I2C_V5.py
    resetval=0
    while [ $resetval -eq 0 ] ; do
        valRightGPIO=$(cat /sys/class/gpio/gpio"$RightBtnGPIO"/value)
        
        # Right Button Long Press Detection
        if [ "$valRightGPIO" -eq "$buttonPressedValue" ]; then
            startHold=$(date +%s)
            while [ "$(cat /sys/class/gpio/gpio"$RightBtnGPIO"/value)" -eq "$buttonPressedValue" ]; do
                currentHold=$(date +%s)
                elapsed=$((currentHold - startHold))
                if [ "$elapsed" -ge "$longPressDuration" ]; then
                    echo "[System]: Right button long press detected, exiting program..."
		    echo -e "\n          Goodbye!" > output.txt
		    python3 OLED_I2C_V5.py
                    exit 0
                fi
                sleep 0.1
            done
        fi

        # Right Button Mode Logic
        if [ "$valRightGPIO" -eq "$buttonPressedValue" ] && [ "$elapsed" -lt "$longPressDuration" ]; then
            LeftBtnSet=false
            if [ "$RightBtnSet" = false ]; then
                if [ "$SYS_MODE" = "INIT" ] || [ "$SYS_MODE" = "VITAL" ]; then
                    SYS_MODE="ID"
                    echo -e " ID Mode \n" > output.txt
                    echo "<= Vitals      Record =>" >> output.txt
                else
                    SYS_MODE="ID"
                    echo -e " ID Mode \n" > output.txt
                    echo "<= Vitals      Record =>" >> output.txt
                fi
                echo "[Button Handler]: Right button pressed, new mode is $SYS_MODE"
                RightBtnSet=true
            else
                export SYS_MODE
                echo "[Button Handler]: Right Pressed Twice - Started recording in $SYS_MODE mode"
                source ./system_control.sh
                echo "[Button Handler]: $SYS_MODE mode complete!"                                                      
		sleep 5
		echo "[Button Handler]: Clearing screen..."
                echo -e "\n    Reseting..." > output.txt
		RightBtnSet=false
		resetval=1
            fi
            python3 OLED_I2C_V5.py
            sleep 0.5  # Debounce delay
	fi

        # Left Button Long Press Detection
        valLeftGPIO=$(cat /sys/class/gpio/gpio"$LeftBtnGPIO"/value)
        if [ "$valLeftGPIO" -eq "$buttonPressedValue" ]; then
            startHold=$(date +%s)
            while [ "$(cat /sys/class/gpio/gpio"$LeftBtnGPIO"/value)" -eq "$buttonPressedValue" ]; do
                currentHold=$(date +%s)
                elapsed=$((currentHold - startHold))
                if [ "$elapsed" -ge "$longPressDuration" ]; then
                    echo "[System]: Left button long press detected, exiting program..."
		    echo -e "\n             Tschuss!" > output.txt
                    python3 OLED_I2C_V5.py
		    exit 0
                fi
                sleep 0.1
            done
        fi

        # Left Button Mode Logic
        if [ "$valLeftGPIO" -eq "$buttonPressedValue" ] && [ "$elapsed" -lt "$longPressDuration" ]; then
            RightBtnSet=false
            if [ "$LeftBtnSet" = false ]; then
                if [ "$SYS_MODE" = "INIT" ] || [ "$SYS_MODE" = "ID" ]; then
                    SYS_MODE="VITAL"
                    echo -e " Vital Mode \n" > output.txt
                    echo "<= Record             ID =>" >> output.txt
                else
                    SYS_MODE="VITAL"
                    echo -e " Vital Mode \n" > output.txt
                    echo "<= Record             ID =>" >> output.txt
                fi
                echo "[Button Handler]: Left button pressed, new mode is $SYS_MODE"
                LeftBtnSet=true
            else
                export SYS_MODE
                echo "[Button Handler]: Left Pressed Twice - Started recording in $SYS_MODE mode"
                source ./system_control.sh
		echo "[Button Handler]: $SYS_MODE mode complete!"
		sleep 5
		echo "[Button Handler]: Clearing screen..."
		echo -e "\n    Reseting..." > output.txt
                LeftBtnSet=false
		resetval=1
            fi
            python3 OLED_I2C_V5.py
            sleep 0.5  # Debounce delay
        fi

        sleep 0.1  # Main loop delay
    done
    sleep 1
done
